<?php wp_footer();?>


<div class="footer-container" style="background-color: gray; height:100%; width:100%;">
        <div class="ft-social" style="text-align: center; padding-top: 20px;">
                <a href="#" class="support" style="color:black;">Contact Us</a>
                <br>
                <a href="#" class="face" style="color:black;">Facebook</a>
                <br>
                <a href="#" class="tweet" style="color:black;">Twitter</a>
                <br>
                <a href="#" class="linked" style="color:black;">Instagram</a>
        </div>

        <br>
        <br>
        <br>

        <div class="copyright">
                <p>&copy 2019 - ARAMAT</p>
        </div>
</div>
</body>
</html>
